import React from "react";

const CardAlbum = ({albumName}) => {
    return (
        <p>{albumName}</p>
    )
}

export {
    CardAlbum
}