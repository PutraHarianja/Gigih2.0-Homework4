import React from "react";

const CardArtist = ({artisName}) => {
    return (
        <p>{artisName}</p>
    )
}

export {
    CardArtist
}