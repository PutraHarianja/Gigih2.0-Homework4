import React from "react";

const CardTitle = ({title}) => {
    return (
        <p>{title}</p>
    )
}

export {
    CardTitle
}